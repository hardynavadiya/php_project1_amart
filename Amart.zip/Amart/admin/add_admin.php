
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from codervent.com/rukada/color-admin/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Dec 2018 05:02:05 GMT -->
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Rukada - Responsive Bootstrap4  Admin Dashboard Template</title>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>

</head>

<body>

<!-- Start wrapper-->
 <div id="wrapper">
 
   <?php require "include/header.php" ?>
   <?php require "include/sidebar.php" ?>

<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Form Validation</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Rukada</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Form Validation</li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-outline-primary waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <form id="signupForm" action="php/admin_insert.php" method="post">
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-address-book-o"></i>
                   Admin Profile
                </h4>
                <div class="form-group row">
                  <label for="input-10" class="col-sm-2 col-form-label">Name</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" id="input-10" name="A_name">
                  </div>
                </div>
                <h4 class="form-header text-uppercase">
                <i class="fa fa-envelope-o"></i>
                  Contact Info & Bio
                </h4>
                <div class="form-group row">
                  <label for="input-14" class="col-sm-2 col-form-label">E-mail</label>
                  <div class="col-sm-8">
                    <input type="email" class="form-control" id="input-14" name="A_email">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-17" class="col-sm-2 col-form-label">Address</label>
                  <div class="col-sm-8">
                    <textarea name="A_address" class="form-control" rows="2" id="input-17"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-14" class="col-sm-2 col-form-label">Contact Number</label>
                  <div class="col-sm-8">
                    <input type="text" pattern="[0-9]{10}" title="only 10 digit allowed" class="form-control" id="input-14" name="A_mono" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-16" class="col-sm-2 col-form-label">Front Proof </label>
                  <div class="col-sm-4">
                    <input type="file" class="form-control" id="input-16" name="A_front_proof">
                  </div>
                  <label for="input-16" class="col-sm-2 col-form-label">Back Proof </label>
                  <div class="col-sm-4">
                    <input type="file" class="form-control" id="input-16" name="A_back_proof">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-14" class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-4">
                    <input type="password" class="form-control" id="input-14" name="A_password">
                  </div>
                  <label for="input-14" class="col-sm-2 col-form-label">Confirm Password</label>
                  <div class="col-sm-4">
                    <input type="password" class="form-control" id="input-14" onkeyup="checkpas();">
                  </div>
                </div>

                <div class="form-footer">
                    <button type="submit" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button>
                    <button type="submit" id="submit" disabled class="btn btn-success"><i class="fa fa-check-square-o"></i>SAVE</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div><!--End Row-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <?php require "include/footer.php" ?>
   
  </div><!--End wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>

  <!--Form Validatin Script-->
    <script src="assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>
    <script>

    $().ready(function() {

    $("#personal-info").validate();

   // validate signup form on keyup and submit
    $("#signupForm").validate({
        rules: {
            firstname: "required",
            lastname: "required",
            username: {
                required: true,
                minlength: 2
            },
            password: {
                required: true,
                minlength: 5
            },
            confirm_password: {
                required: true,
                minlength: 5,
                equalTo: "#password"
            },
            email: {
                required: true,
                email: true
            },
             contactnumber: {
                required: true,
                minlength: 10
            },
            topic: {
                required: "#newsletter:checked",
                minlength: 2
            },
            agree: "required"
        },
        messages: {
            firstname: "Please enter your firstname",
            lastname: "Please enter your lastname",
            username: {
                required: "Please enter a username",
                minlength: "Your username must consist of at least 2 characters"
            },
            password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 5 characters long"
            },
            confirm_password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 5 characters long",
                equalTo: "Please enter the same password as above"
            },
            email: "Please enter a valid email address",
            contactnumber: "Please enter your 10 digit number",
            agree: "Please accept our policy",
            topic: "Please select at least 2 topics"
        }
    });

});

    </script>
  
</body>

<!-- Mirrored from codervent.com/rukada/color-admin/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Dec 2018 05:02:08 GMT -->
</html>
