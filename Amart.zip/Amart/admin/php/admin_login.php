<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		extract($_POST);
		
		$tablename = "admin";

		$f_no_redirect = "../login.php";
		$s_redirect = "../dashboard.php";

		$no_data = "you have no data";
		$no_p_data = "pwd is wrong";
		$f_msg = "please contact developer";
		$s_msg = "login succesfully";
		
		 //$select = "*";
		$select = "`A_id`";
		

		include "maincode/login.php";
	}
?>