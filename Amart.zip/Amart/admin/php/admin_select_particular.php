<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="GET")
	{
		$tablename = "admin";

		$f_no_redirect = "index.php";
		$f_redirect = "admin.php";

		$no_data = "you have no data";
		$f_msg = "please contact developer";
		
		$select = "*";
		//$select = "`id`, `name`";

		//$where = "`A_id` = '$_SESSION[a_id]'"
		$where = "`A_id` = '3'";

		include "maincode/select_particular.php";
	}
?>