<?php
	include "config.php";
	include "session.php";
	if ($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$id=$_POST['id'];
		$sql="SELECT `P_image` FROM `product` WHERE `P_id`='$id'";
		//echo $sql;
		$result=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_assoc($result))
			{
				$oldimage=$row['P_image'];
			}
		}
		/*if($name=="" || $color=="" || $size=="" || $price=="" ||$catid=="" || $subcatid=="")
		{
			echo "<script>
			alert ('pls fill the detail');
			window.location.href='../html/product.php';
			</script>";
		}
		//image upload path*/
		$dir="../image/product/";
		//echo $dir;

		//get image name (image is name of form image)
		$image = basename($_FILES["image"]["name"]);
		//print_r ($image);

		//  upload path varible + get image name
		$file=$dir.$image;
		//	echo $file;
		//image type extension
		$type=strtolower(pathinfo($file,PATHINFO_EXTENSION));
		//echo $type;
		
		//check file is image or not where tmp_name is default and it is use for the send the image on server through  temporary name
		$check = getimagesize($_FILES["image"]["tmp_name"]);
		//print_r($check);
		
		if($check == false) {
			echo "<script>
			alert ('file is not image');
			window.location.href='../html/product.php';
			</script>";
		}

		//file is already exist
		if(file_exists($file))
		{
			echo "<script>
			alert ('file is already exist');
			window.location.href='../html/product.php';
			</script>";
		}
		//check file size
		if($_FILES["image"]["size"] > 625000) {
			echo "<script>
			alert ('file is too large');
			window.location.href='../html/product.php';
			</script>";
		}

		//allow ceratain file format
		if($type != "jpg" && $type != "png" && $type !== "jpeg")
		{
			echo "<script>
			alert ('only allow jpg, png, jpeg ');
			window.location.href='../html/product.php';
			</script>";
		}

		$sql="UPDATE `product` SET `P_image`='$image' WHERE `P_id`='$id'";
		echo $sql;

		if(mysqli_query($conn,$sql))
		{	
			if(move_uploaded_file($_FILES["image"]["tmp_name"], $file))
			{
				unlink($dir.$oldimage);
				echo "<script>
				alert('data inserted');
				</script>";
			}		
			else
			{
				echo "<script>
				alert('plz upload your product image');
				</script>";	
			}
		}
		else
		{
			echo mysqli_error($conn);
		}
	}
?>