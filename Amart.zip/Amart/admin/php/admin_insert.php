<?php
	include "maincode/config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$tablename = "admin";

		$s_redirect = "../index.php";
		$f_redirect = "../add_admin.php";

		$s_msg = "successfully admin created";
		$f_msg = "please contact developer";
		
		extract($_POST);
		$_POST['A_password'] = md5($_POST['A_password']);
		$keys = array_keys($_POST);
		$columnname = implode("`,`", $keys);
		$values = implode("','", $_POST);

		include "maincode/insert.php";
	}
?>