<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$tablename = "admin";

		$s_redirect = "index.php";
		$f_redirect = "admin.php";

		$s_msg = "successfully admin updated";
		$f_msg = "please contact developer";

		$set = "";

		foreach ($_POST as $key => $value) {
			$set .= "`".$key."` = '".$value."', ";
		}
		$set = rtrim($set,", ");

		include "maincode/update.php";
	}
?>