<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$tablename = "sub_category";
		
		$s_redirect = "../dashboard.php";
		$f_redirect = "../subcategory.php";

		$s_msg = "succesfully subcategory added";
		$f_msg = "please contact devloaper";
		// $f_msg = mysqli_error($conn);

		extract($_POST);
		
		$keys = array_keys($_POST);
		
		$columnname = implode("`,`",$keys);
		$values = implode("','", $_POST);

		include "maincode/insert.php";
	}
?>