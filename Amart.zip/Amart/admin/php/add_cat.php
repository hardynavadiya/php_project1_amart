<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$tablename = "category_master";
		
		$s_redirect = "../dashboard.php";
		$f_redirect = "../category.php";

		$s_msg = "succesfully category addesd";
		$f_msg = "please contact devloaper";
		// $f_msg = mysqli_error($conn);

		extract($_POST);
		
		$keys = array_keys($_POST);
		
		$columnname = implode("`,`",$keys);
		$values = implode("','", $_POST);

		include "maincode/insert.php";
	}
?>