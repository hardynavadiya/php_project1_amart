<?php
	include "config.php";
	if($_SERVER["REQUEST_METHOD"]=="GET")
	{
		$tablename = "sub_category";

		$f_no_redirect = "index.php";
		$f_redirect = "admin.php";

		$no_data = "you have no data";
		$f_msg = "please contact developer";
		
		$select = "*";
		//$select = "`A_id`, `A_name`";
	
		include "maincode/select.php";
	}
?>