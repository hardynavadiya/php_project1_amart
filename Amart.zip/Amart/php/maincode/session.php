<?php
	session_start();
	if (!isset($_SESSION["U_id"]) && empty($_SESSION["U_id"]))
	{
		echo "<script>
				alert('plz login');
				window.location.href='../../index.php';
		</script>";
	}
	// else
	// {
	// 	echo "success";
	// }
?>