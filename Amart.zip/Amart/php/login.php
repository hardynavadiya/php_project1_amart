<?php
	include "maincode/config.php";
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{

		extract($_POST);

		$tablename = "user";

		$f_no_redirect = "../login.php";
		$s_redirect = "../index.php";

		$no_data = "you have no data";
		$no_p_data = "pwd is wrong";
		$f_msg = "please contact developer";
		$s_msg = "login successfully";
		
		// $select = "*";
		$select = "`U_id`";
		

		include "maincode/login.php";
	}
?>