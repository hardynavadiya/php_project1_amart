<!--Start-header-mid-area-->
<div class="header-mid-wrap">
    <div class="container">
        <div class="header-mid-content">
            <div class="row">
                <!--Start-logo-area-->
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <div class="header-logo">
                        <a href="index.php"><img src="images/logo/1.png" alt="OurStore"></a>
                    </div>
                </div>
                <!--End-logo-area-->
                <!--Start-gategory-searchbox-->
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div id="search-category-wrap">
                        <form class="header-search-box" action="#" method="post">
                            <div class="search-cat">
                                <select class="category-items" name="category">
                                    <option>All Categories</option>
                                    <option>Men</option>
                                    <option>Women</option>
                                    <option>Jewellery</option>
                                    <option>Electronics</option>
                                    <option>Kid</option>
                                    <option>Bootees Bags</option>
                                    <option>Clothing</option>
                                    <option>Footwear</option>
                                    <option>T-Shirts</option>
                                    <option>Polo-Shirts</option>
                                </select>
                            </div>
                            <input type="search" placeholder="Search here..." id="text-search" name="search">
                            <button id="btn-search-category" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <!--End-gategory-searchbox-->
                <!--Start-cart-wrap-->
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <ul class="header-cart-wrap">
                        <li><a class="cart" href="#">My Cart: 2 items</a>
                            <div class="mini-cart-content">
                                <div class="cart-products-list">
                                    <div class="sing-cart-pro">
                                        <div class="cart-image">
                                            <a href="#"><img src="images/product/4.jpg" alt=""></a>
                                        </div>
                                        <div class="cart-product-info">
                                            <a href="#" class="product-name"> Sample product </a>
                                            <div class="cart-price">
                                                <span class="quantity"><strong> 1 x</strong></span>
                                                <span class="p-price">$110.00</span>
                                            </div>
                                            <a class="edit-pro" title="edit"><i class="fa fa-pencil-square-o"></i></a>
                                            <a class="remove-pro" title="remove"><i class="fa fa-times"></i></a>
                                        </div>
                                    </div>
                                    <div class="sing-cart-pro">
                                        <div class="cart-image">
                                            <a href="#"><img src="images/product/1.jpg" alt=""></a>
                                        </div>
                                        <div class="cart-product-info">
                                            <a href="#" class="product-name">Sample product </a>
                                            <div class="cart-price">
                                                <span class="quantity"><strong> 1 x</strong></span>
                                                <span class="p-price">$150.00</span>
                                            </div>
                                            <a class="edit-pro" title="edit"><i class="fa fa-pencil-square-o"></i></a>
                                            <a class="remove-pro" title="remove"><i class="fa fa-times"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-price-list">
                                    <p class="price-amount"><span class="cart-subtotal">SUBTotal :</span> <span>$260.00</span> </p>
                                    <div class="cart-checkout">
                                        <a href="#">Checkout</a>
                                    </div>
                                    <div class="view-cart">
                                        <a href="#">View cart</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <!--End-cart-wrap-->
            </div>
        </div>
    </div>
</div>
<!--End-header-mid-area-->