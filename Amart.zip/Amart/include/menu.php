<!--Start-Mainmenu-area -->
<div class="mainmenu-area hidden-sm hidden-xs">
    <div id="sticker">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 hidden-sm hidden-xs">
                    <div class="log-small"><a class="logo" href="index.php"><img alt="OurStore" src="images/logo/s.png"></a></div>
                    <div class="mainmenu">
                        <nav>
                            <ul id="nav">
                                <li><a href="index.php">Home</a>
                                </li>
                                <li class="angle-down"><a href="shop-grid.php">Men</a>
                                    <div class="megamenu">
                                        <div class="megamenu-list">
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Clothing</a>
                                                <a href="shop-grid.php">Jackets</a>
                                                <a href="shop-grid.php">Blazers</a>
                                                <a href="shop-grid.php">T-Shirts</a>
                                                <a href="#">Collections</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Dresses</a>
                                                <a href="shop-grid.php">Evening</a>
                                                <a href="shop-grid.php">Cocktail</a>
                                                <a href="shop-grid.php">Footwear</a>
                                                <a href="shop-grid.php">Sunglass</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Handbags</a>
                                                <a href="shop-grid.php">Bootees Bags</a>
                                                <a href="shop-grid.php">Exclusive</a>
                                                <a href="shop-grid.php">Furniture</a>
                                                <a href="shop-grid.php">Jackets</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Jewellery</a>
                                                <a href="shop-grid.php">Earrings</a>
                                                <a href="shop-grid.php">Braclets</a>
                                                <a href="shop-grid.php">Nosepins</a>
                                                <a href="shop-grid.php">Bangels</a>
                                            </span>
                                            <span>
                                                <a href="shop-grid.php" class="mega-banner">
                                                    <img src="images/menu/1.jpg" alt="Hi">
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </li>
                                <li class="angle-down"><a href="shop-grid.php">Women</a>
                                    <div class="megamenu">
                                        <div class="megamenu-list">
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Clothing</a>
                                                <a href="shop-grid.php">Jackets</a>
                                                <a href="shop-grid.php">Blazers</a>
                                                <a href="shop-grid.php">T-Shirts</a>
                                                <a href="#">Collections</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Dresses</a>
                                                <a href="shop-grid.php">Cocktail</a>
                                                <a href="shop-grid.php">Evening</a>
                                                <a href="shop-grid.php">Footwear</a>
                                                <a href="shop-grid.php">Sunglass</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Handbags</a>
                                                <a href="shop-grid.php">Bootees Bags</a>
                                                <a href="shop-grid.php">Exclusive</a>
                                                <a href="shop-grid.php">Furniture</a>
                                                <a href="shop-grid.php">Jackets</a>
                                            </span>
                                            <span class="mega-single">
                                                <a href="shop-grid.php" class="mega-title">Jewellery</a>
                                                <a href="shop-grid.php">Earrings</a>
                                                <a href="shop-grid.php">Braclets</a>
                                                <a href="shop-grid.php">Nosepins</a>
                                                <a href="shop-grid.php">Bangels</a>
                                            </span>
                                            <span>
                                                <a href="shop-grid.php" class="mega-banner">
                                                    <img src="images/menu/2.jpg" alt="Hi">
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                </li>
                                <li><a href="shop-grid.php">Footwear</a></li>
                                <li><a href="shop-grid.php">Accessories</a>
                                </li>
                                <li class="angle-down"><a href="shop-grid.php">Pages</a>
                                    <div class="megamenu pages">
                                        <div class="megamenu-list">
                                            <span class="mega-single pages">
                                                <a href="about-us.php">About Us</a>
                                                <a href="checkout.php">Checkout</a>
                                                <a href="wishlist.php">Wishlist</a>
                                                <a href="shopping-cart.php">Shopping Cart</a>
                                                <a href="shop-grid.php">Shop Grid</a>
                                                <a href="shop-list.php">Shop List</a>
                                                <a href="shop-right-sidebar.php">Shop Right Sidbar</a>
                                                <a href="my-account.php">My Account</a>
                                                <a href="login.php">Login</a>
                                                <a href="contact-us.php">Contact v1</a>
                                                <a href="contact-v2.php">Contact v2</a>
                                                <a href="portfolio.php">Portfolio</a>
                                                <a href="portfolio-details.php">Portfolio Details</a>
                                                <a href="collection-list.php">Collection List</a>
                                            </span>
                                            <span class="mega-single pages">
                                                <a href="single-product.php">Single Product</a>
                                                <a href="single-product-left-sidebar.php">Single Product Left sidebar</a>
                                                <a href="single-product-right-sidebar.php">Single Product Right Sidebar</a>
                                                <a href="single-product-sidebar-reviews.php">Single Product  Reviews</a>
                                                <a href="blog.php">Blog</a>
                                                <a href="blog-details.php">Blog Details</a>
                                                <a href="blog-grid.php">Blog Grid</a>
                                                <a href="blog-left-sidebar.php">Blog Left Sidebar</a>
                                                <a href="blog-right-sidebar.php">Blog Right Sidebar</a>
                                                <a href="blog-fullwidth.php">Blog Fullwidth</a>
                                                <a href="gallery.php">Gallery</a>
                                                <a href="gallery-details.php">Gallery Details</a>
                                                <a href="404.php">404</a>
                                            </span>
                                        </div>
                                    </div>
                                </li>
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End-Mainmenu-area-->