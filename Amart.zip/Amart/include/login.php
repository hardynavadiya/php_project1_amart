<?php
session_start();
?>
<div class="header-top-wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="header-top-left">
                    <!--Start-Header-language-->
                    <div class="dropdown top-language-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-language dropdown-toggle" href="#"> <img src="images/flag/e.png" alt="language"> English <span class="caret"></span> </a>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation"><a role="menuitem" href="#"><img src="images/flag/e.png" alt="language"> English </a></li>
                            <li role="presentation"><a role="menuitem" href="#"><img src="images/flag/f.png" alt="language"> French </a></li>
                            <li role="presentation"><a role="menuitem" href="#"><img src="images/flag/g.png" alt="language"> German </a></li>
                        </ul>
                    </div>
                    <!--End-Header-language-->
                    <!--Start-Header-currency-->
                    <div class="dropdown top-currency-wrap"> <a role="button" data-toggle="dropdown" data-target="#" class="top-currency dropdown-toggle" href="#"><span class="usd-icon"><i class="fa fa-usd"></i></span> USD <span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li role="presentation"><a role="menuitem" href="#"> $ - Dollar </a></li>
                            <li role="presentation"><a role="menuitem" href="#"> £ - Pound </a></li>
                            <li role="presentation"><a role="menuitem" href="#"> € - Euro </a></li>
                        </ul>
                    </div>
                    <!--End-Header-currency-->
                    <!--Start-welcome-message-->
                    <div class="welcome-mg hidden-xs"><span>Default Welcome Message!</span></div>
                    <!--End-welcome-message-->
                </div>
            </div>
            <!-- Start-Header-links -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="header-top-right">
                    <div class="top-link-wrap">
                        <div class="single-link">
                        <?php if (!isset($_SESSION["U_id"]) && empty($_SESSION["U_id"])) { ?>
                            <div class="my-account"><a href="my-account"><span class=""> Registration</span></a></div>
                        <?php } else { ?>
                            <div class="my-account"><a href="my-account.php"><span class=""> My Account</span></a></div>
                        <?php } ?>
                            <div class="wishlist"><a href="wishlist.php"><span class="">Wishlist</span></a></div>
                            <div class="check"><a href="checkout.php"><span class="">Checkout</span></a></div>
                        <?php if (!isset($_SESSION["U_id"]) && empty($_SESSION["U_id"])) { ?>
                            <div class="login"><a href="login"><span  class="">Log In</span></a></div>
                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
             <!-- End-Header-links -->
        </div>
    </div>
</div>